from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app import models, schemas
from app.deps import get_current_user

router = APIRouter(prefix="/api/comments", tags=["comments"])

@router.post("/", response_model=schemas.CommentOut)
def add_comment(payload: schemas.CommentCreate, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    cand = db.query(models.Candidate).get(payload.candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found")
    com = models.Comment(user_id=user.id, candidate_id=payload.candidate_id, content=payload.content)
    db.add(com); db.commit(); db.refresh(com)
    return com

@router.get("/candidate/{candidate_id}", response_model=list[schemas.CommentOut])
def list_comments(candidate_id: int, db: Session = Depends(get_db)):
    return db.query(models.Comment).filter(models.Comment.candidate_id == candidate_id).order_by(models.Comment.created_at.desc()).all()
