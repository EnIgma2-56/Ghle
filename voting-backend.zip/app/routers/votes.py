from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.database import get_db
from app import models, schemas
from app.deps import get_current_user

router = APIRouter(prefix="/api/votes", tags=["votes"])

@router.post("/", response_model=schemas.VoteOut)
def cast_vote(payload: schemas.VoteIn, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    # Check position & candidate
    position = db.query(models.Position).get(payload.position_id)
    candidate = db.query(models.Candidate).get(payload.candidate_id)
    if not position or not candidate or candidate.position_id != position.id:
        raise HTTPException(status_code=400, detail="Invalid position/candidate")
    # Check if user already voted for this position
    existing = db.query(models.Vote).filter(
        models.Vote.user_id == user.id,
        models.Vote.position_id == payload.position_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="You already voted for this position")
    vote = models.Vote(user_id=user.id, position_id=payload.position_id, candidate_id=payload.candidate_id)
    db.add(vote); db.commit(); db.refresh(vote)
    return vote

@router.get("/results/{position_id}")
def results(position_id: int, db: Session = Depends(get_db)):
    # Returns tally per candidate for a position
    from sqlalchemy import func
    rows = (db.query(models.Candidate.id, models.Candidate.name, func.count(models.Vote.id).label("votes"))
              .outerjoin(models.Vote, models.Vote.candidate_id == models.Candidate.id)
              .filter(models.Candidate.position_id == position_id)
              .group_by(models.Candidate.id, models.Candidate.name)
              .order_by(func.count(models.Vote.id).desc())
              .all())
    return [{"candidate_id": r.id, "name": r.name, "votes": int(r.votes)} for r in rows]
