from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app import models
from app.deps import require_admin

router = APIRouter(prefix="/api/admin", tags=["admin"])

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), _: models.User = Depends(require_admin)):
    total_users = db.query(func.count(models.User.id)).scalar() or 0
    total_candidates = db.query(func.count(models.Candidate.id)).scalar() or 0
    total_votes = db.query(func.count(models.Vote.id)).scalar() or 0
    positions = db.query(models.Position).all()
    per_position = []
    for p in positions:
        count = db.query(func.count(models.Vote.id)).filter(models.Vote.position_id == p.id).scalar() or 0
        per_position.append({"position_id": p.id, "position": p.name, "votes": int(count)})
    return {
        "totals": {
            "users": int(total_users),
            "candidates": int(total_candidates),
            "votes": int(total_votes)
        },
        "per_position": per_position
    }
