from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app import models, schemas
from app.deps import get_current_user, require_admin

router = APIRouter(prefix="/api", tags=["candidates","positions"])

# === Positions ===
@router.post("/positions", response_model=schemas.PositionOut)
def create_position(payload: schemas.PositionCreate, db: Session = Depends(get_db), _: models.User = Depends(require_admin)):
    pos = models.Position(name=payload.name, description=payload.description)
    db.add(pos); db.commit(); db.refresh(pos)
    return pos

@router.get("/positions", response_model=list[schemas.PositionOut])
def list_positions(db: Session = Depends(get_db)):
    return db.query(models.Position).all()

# === Candidates ===
@router.post("/candidates", response_model=schemas.CandidateOut)
def create_candidate(payload: schemas.CandidateCreate, db: Session = Depends(get_db), _: models.User = Depends(require_admin)):
    position = db.query(models.Position).get(payload.position_id)
    if not position:
        raise HTTPException(status_code=404, detail="Position not found")
    cand = models.Candidate(
        name=payload.name,
        manifesto=payload.manifesto,
        photo_url=payload.photo_url,
        position_id=payload.position_id
    )
    db.add(cand); db.commit(); db.refresh(cand)
    return cand

@router.get("/candidates", response_model=list[schemas.CandidateOut])
def list_candidates(db: Session = Depends(get_db)):
    return db.query(models.Candidate).all()

@router.get("/positions/{position_id}/candidates", response_model=list[schemas.CandidateOut])
def list_candidates_by_position(position_id: int, db: Session = Depends(get_db)):
    return db.query(models.Candidate).filter(models.Candidate.position_id == position_id).all()

@router.delete("/candidates/{candidate_id}")
def delete_candidate(candidate_id: int, db: Session = Depends(get_db), _: models.User = Depends(require_admin)):
    cand = db.query(models.Candidate).get(candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found")
    db.delete(cand); db.commit()
    return {"ok": True}
