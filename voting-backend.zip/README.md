# SecureVote Backend (FastAPI + SQLAlchemy)

A minimal yet complete backend for a student voting system with admin and user features.

## Features
- JWT Auth (signup/login)
- Admin: add/edit/delete candidates & positions, view dashboard
- Students: vote once per **position**, comment on candidates
- Results endpoint per position
- CORS-enabled for JS frontends (Netlify, Vercel, etc.)
- Works with PostgreSQL (Render) or SQLite (local)

## Quickstart (Local)

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Use SQLite if you don't have Postgres locally
export DATABASE_URL=sqlite:///./dev.db  # Windows (PowerShell): $Env:DATABASE_URL='sqlite:///./dev.db'
export JWT_SECRET=devsecret

uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open: http://127.0.0.1:8000/docs

## Deploy to Render

1. Push this repo to GitHub.
2. Create a new **Web Service** in Render → connect the repo.
3. **Build Command**: `pip install -r requirements.txt`
4. **Start Command**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
5. **Environment Variables**:
   - `DATABASE_URL` (Render PostgreSQL connection string)
   - `JWT_SECRET` (random secret)
   - `JWT_ALG` (default HS256)
   - `CORS_ORIGINS` (comma-separated list or `*`)
   - `ADMIN_EMAIL` / `ADMIN_PASSWORD` (optional: auto-create admin user at startup)

**Common Render error**: `ModuleNotFoundError: No module named 'app'`  
Make sure your project root contains the `app/` folder and you run with `uvicorn app.main:app`.

## Project Structure

```
app/
  core/
    config.py
  main.py
  database.py
  models.py
  schemas.py
  security.py
  deps.py
  routers/
    auth.py
    users.py
    candidates.py
    votes.py
    comments.py
    admin.py
```

## Notes
- This project auto-creates tables on startup (no Alembic for simplicity).
- `Vote` table enforces one vote per user per position via a unique constraint.
- Update `CORS_ORIGINS` to your frontend domain(s) when you go live.
